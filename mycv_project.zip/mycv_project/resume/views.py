from django.shortcuts import render

def resume_view(request):
    context = {
        'name': 'Ashwin A. Sharma',
        'email': 'sharmaashwin4000@gmail.com',
        'github': 'Github',
        'linkedin': 'LinkedIn',
        'objective': 'To provide for the world, with the best of my capabilities as a human. Using computer science as a tool empowers my aim to make a meaningful change by imagining, innovating, and building new technologies.',
        'education': {
            'university1': {
                'name': 'University of Mumbai, BE, India',
                'degree': 'Major: Computer Science',
                'cgpa': '8.21/10',
                'duration': '2019–2023',
                'project': 'Smart glasses AI software',
                'committee': 'Prof. Dr. Harshali Patil, Megharani Patil, and Manish Rana'
            },
            'university2': {
                'name': 'New York University',
                'degree': 'MS in Computer Science',
                'gpa': '3.55',
                'duration': 'Sept. 2024 - May 2026'
            }
        },
        'publications': [
            {
                'title': 'A. Sharma, D. Devalia, W. Almeida, H. Patil and A. Mishra, “Statistical Data Analysis using GPT3: An Overview,”',
                'conference': '2022 IEEE Bombay Section Signature Conference (IBSSC), Mumbai, India',
                'year': '2022',
                'doi': '10.1109/IBSSC56953.2022.10037383'
            },
            {
                'title': 'A. Sharma, D. S. Bisht, D. Devalia and M. Patil, “Dynamic Simulation Environment for Pandemic Management: Study of Proximal Policy Optimization on a Novel Simulation Using Reinforcement Learning,”',
                'conference': '2023 Int’l Conf. on Communication, Security and Artificial Intelligence (ICCSAI), Greater Noida, India',
                'year': '2023',
                'doi': '10.1109/ICCSAI59793.2023.10421231'
            }
        ],
        'research_projects': [
            {
                'name': 'Assistive Technology Development for the Visually Impaired',
                'details': [
                    'Developed an Android app for smart glasses that translates text to audio for the visually impaired.',
                    'Employed Python, GPT-3, Google Vision API, and Android Studio for accurate text recognition.',
                    'The project used GPT and Google Vision API to understand visuals.'
                ]
            },
            {
                'name': 'Pandemic Simulation Developer',
                'details': [
                    'Reengineered a 2D grid-based dynamic pandemic simulation using Numpy, achieving 700x performance optimization.',
                    'Designed and integrated Double Deep Q-Network and PPO models for strategic lockdown planning.',
                    'Developed the full simulation environment in two months, exploring the extremes of epidemiology.'
                ]
            },
            {
                'name': 'RAG System Implementation for ROS2 Robotics Development',
                'details': [
                    'Built a Retrieval Augmented Generation (RAG) system to assist ROS2 navigation and egomotion tasks.',
                    'Employed Qdrant (Cloud), MongoDB Atlas, and ClearML for vector storage, data management, and experiment tracking.',
                    'Fine-tuned a 4-bit “phi-3.5-mini-instruct” model with LoRA; used GPT4o-mini to generate 1700+ instruct examples.',
                    'System covers ROS2, Nav2, MoveIt2, and Gazebo domain knowledge, delivering accurate, context-aware responses.',
                    'Incorporated a Gradio interface for user queries; integrated unslot to optimize training under budget constraints.'
                ]
            }
        ],
        'professional_experience': {
            'company': 'NextapAI',
            'position': 'Cofounder/CEO',
            'tasks': [
                'Brew NextapAI into a profitable five-figure dollar revenue business within six months.',
                'Spearheaded development of Codilarity.com, focusing on frontend and backend integration.',
                'Led a team of eight, fostering skills in management, software development, and team coordination.',
                'Innovated the recruitment process by introducing short video evaluations.',
                'Provided consultancy services to top-tier educational institutions, banks, and corporations.',
                'Trained 20+ students’ class for several months, partnering with ViaLYTICS Pvt Ltd (85% Placement Record — 54% Average Salary Hike).',
                'Developed contract-based financial trading instruments using ML, PSO, and genetic algorithm combinations.',
                'Played a vital role in over 300 projects across FinTech, AI, software development, and cloud computing since 2022.',
                'Fine-tuned a 4-bit model to create a tailored documentation helper, reducing dev time by 40% and boosting profit margins by 50%.'
            ]
        },
        'research_interests': [
            'Artificial Intelligence',
            'Software Development',
            'Physics Engine',
            'Automation',
            'Project Management',
            'Business Analysis',
            'Cybersecurity',
            'LLMs',
            'Network Security',
            'Simulations',
            'Computer in Finance-Trading Bots',
            'Computer Vision and Graphics'
        ],
        'skills': [
            'Proficient in Python, Java, C++, C, C#, JavaScript, Node.js, HTML, CSS, Dart.',
            'Expert-level handling of Selenium, Pycharm, Unity3D, Android Studio, Figma, Ideal, TensorFlow.',
            'AI Solutions, Prompting GenAI, Frontend & Backend Development, Project Management, Recruitment Process Innovation, Game Development, Project Optimization, Highspeed Coding.'
        ]
    }
    return render(request, 'resume_template.html', context)